# Project Structure & File Documentation

## 📁 Complete Directory Layout

```
Task Manager App/
│
├── README.md                    # Main project documentation
├── QUICKSTART.md               # Quick start guide
├── DEPLOYMENT.md               # Production deployment guide
├── API_REFERENCE.md            # Detailed API documentation
│
├── client/                     # React Frontend Application
│   │
│   ├── index.html             # HTML entry point
│   ├── package.json           # NPM dependencies & scripts
│   ├── vite.config.js         # Vite configuration
│   ├── tailwind.config.js     # Tailwind CSS configuration
│   ├── postcss.config.js      # PostCSS configuration
│   ├── vercel.json            # Vercel deployment config
│   │
│   ├── .env                   # Local environment variables
│   ├── .env.example           # Environment template
│   ├── .gitignore             # Git ignore rules
│   │
│   └── src/
│       │
│       ├── main.jsx           # React entry point
│       ├── App.jsx            # Main app component with routing
│       ├── index.css          # Global styles & Tailwind imports
│       │
│       ├── components/        # Reusable UI components
│       │   ├── Header.jsx              # Top navigation bar
│       │   ├── TaskFilters.jsx         # Search & filter controls
│       │   ├── KanbanBoard.jsx         # Main Kanban layout
│       │   ├── TaskColumn.jsx          # Individual column
│       │   ├── TaskCard.jsx            # Task card display
│       │   ├── TaskModal.jsx           # Create task modal
│       │   └── EditTaskModal.jsx       # Edit task modal
│       │
│       ├── pages/             # Page components
│       │   ├── Login.jsx               # Login page
│       │   ├── Register.jsx            # Registration page
│       │   └── Dashboard.jsx           # Main dashboard
│       │
│       ├── services/          # API communication
│       │   ├── api.js                  # Axios instance with interceptors
│       │   ├── authService.js          # Auth API calls
│       │   └── taskService.js          # Task API calls
│       │
│       ├── context/           # Global state management
│       │   ├── AuthContext.jsx         # Authentication state
│       │   └── TaskContext.jsx         # Task state & methods
│       │
│       ├── hooks/             # Custom React hooks
│       │   └── useLocalStorage.js      # Local storage hook
│       │
│       ├── routes/            # Route components
│       │   └── PrivateRoute.jsx        # Protected route wrapper
│       │
│       └── utils/             # Utility functions
│           └── dateFormatter.js        # Date formatting functions
│
└── server/                     # Express Backend Application
    │
    ├── server.js              # Express app entry point
    ├── package.json           # NPM dependencies & scripts
    ├── render.yaml            # Render deployment config
    │
    ├── .env                   # Local environment variables
    ├── .env.example           # Environment template
    ├── .gitignore             # Git ignore rules
    │
    ├── config/                # Configuration files
    │   ├── db.js                       # MongoDB connection
    │   └── constants.js                # App constants
    │
    ├── models/                # Database schemas
    │   ├── User.js                     # User model with auth methods
    │   └── Task.js                     # Task model
    │
    ├── controllers/           # Business logic
    │   ├── authController.js           # Auth endpoints logic
    │   └── taskController.js           # Task endpoints logic
    │
    ├── routes/                # API routes
    │   ├── authRoutes.js               # Auth routes
    │   └── taskRoutes.js               # Task routes
    │
    ├── middleware/            # Custom middleware
    │   ├── auth.js                     # JWT authentication middleware
    │   └── errorHandler.js             # Global error handler
    │
    └── utils/                 # Utility functions
        ├── jwt.js                      # JWT token functions
        └── validators.js               # Input validators
```

## 📄 File Descriptions

### Root Files

| File | Purpose |
|------|---------|
| `README.md` | Complete project documentation, features, installation, API docs |
| `QUICKSTART.md` | Quick setup and test guide to get running in 5 minutes |
| `DEPLOYMENT.md` | Step-by-step production deployment guide |
| `API_REFERENCE.md` | Detailed API endpoint documentation with examples |

### Frontend - Configuration Files

| File | Purpose |
|------|---------|
| `client/package.json` | Dependencies: React, Vite, Tailwind, Axios, etc. |
| `client/vite.config.js` | Vite build tool configuration |
| `client/tailwind.config.js` | Tailwind CSS customization |
| `client/postcss.config.js` | PostCSS plugins configuration |
| `client/vercel.json` | Vercel deployment settings |
| `client/index.html` | HTML template with root div |

### Frontend - Environment

| File | Purpose |
|------|---------|
| `client/.env` | Local environment variables (dev) |
| `client/.env.example` | Template for environment variables |

### Frontend - Source Code

| File | Purpose |
|------|---------|
| `src/main.jsx` | React root entry point |
| `src/App.jsx` | Main component with routing setup |
| `src/index.css` | Global styles and Tailwind directives |

### Frontend - Components

| Component | Purpose |
|-----------|---------|
| `Header.jsx` | Top navigation, user info, logout |
| `TaskFilters.jsx` | Search, priority filter, stage filter, clear filters |
| `KanbanBoard.jsx` | Main layout with "Add Task" button |
| `TaskColumn.jsx` | Column container for each stage |
| `TaskCard.jsx` | Individual task display with edit/delete |
| `TaskModal.jsx` | Create new task modal |
| `EditTaskModal.jsx` | Edit existing task modal |

### Frontend - Pages

| Page | Purpose | Route |
|------|---------|-------|
| `Login.jsx` | User login form | `/login` |
| `Register.jsx` | User registration form | `/register` |
| `Dashboard.jsx` | Main dashboard with Kanban board | `/dashboard` |

### Frontend - Services

| Service | Purpose |
|---------|---------|
| `api.js` | Axios instance with JWT interceptors |
| `authService.js` | Register, login, logout, getCurrentUser |
| `taskService.js` | Create, read, update, delete tasks |

### Frontend - Context (State)

| Context | Manages |
|---------|---------|
| `AuthContext.jsx` | User authentication state, login/register/logout |
| `TaskContext.jsx` | Tasks list, filters, create/update/delete operations |

### Frontend - Utilities

| File | Functions |
|------|-----------|
| `hooks/useLocalStorage.js` | localStorage hook |
| `routes/PrivateRoute.jsx` | Route protection component |
| `utils/dateFormatter.js` | Date formatting and date utilities |

### Backend - Configuration

| File | Purpose |
|------|---------|
| `server.js` | Express app setup, middleware, routes |
| `package.json` | Dependencies: Express, MongoDB, JWT, bcrypt |
| `render.yaml` | Render.com deployment configuration |
| `config/db.js` | MongoDB connection setup |
| `config/constants.js` | App constants (stages, priorities) |

### Backend - Environment

| File | Purpose |
|------|---------|
| `server/.env` | Local environment variables |
| `server/.env.example` | Template for required variables |

### Backend - Database Models

| Model | Purpose |
|-------|---------|
| `User.js` | User schema with password hashing |
| `Task.js` | Task schema with priority and stage |

### Backend - Controllers

| Controller | Purpose |
|-----------|---------|
| `authController.js` | Register, login, getMe endpoints |
| `taskController.js` | CRUD operations for tasks |

### Backend - Routes

| Route | Purpose |
|-------|---------|
| `authRoutes.js` | `/auth/register`, `/auth/login`, `/auth/me` |
| `taskRoutes.js` | `/tasks` CRUD endpoints (protected) |

### Backend - Middleware

| Middleware | Purpose |
|-----------|---------|
| `auth.js` | JWT verification for protected routes |
| `errorHandler.js` | Global error handling |

### Backend - Utilities

| Utility | Functions |
|---------|-----------|
| `jwt.js` | generateToken, verifyToken |
| `validators.js` | Email, password, task validation |

## 🔗 Key Dependencies

### Frontend
- **React 18.2.0**: UI library
- **Vite 4.1.0**: Build tool
- **Tailwind CSS 3.2.7**: Styling
- **Axios 1.3.0**: HTTP client
- **React Router 6.8.0**: Routing
- **React Hot Toast 2.4.0**: Notifications
- **Lucide React 0.263.1**: Icons

### Backend
- **Express 4.18.2**: Web framework
- **Mongoose 7.0.0**: MongoDB ODM
- **JWT (jsonwebtoken) 9.0.0**: Token authentication
- **bcryptjs 2.4.3**: Password hashing
- **CORS 2.8.5**: Cross-origin support
- **Express Validator 7.0.0**: Input validation

## 🔄 Data Flow

### Authentication Flow
1. User registers/logs in → Form submission
2. Frontend calls `authService` → API call to backend
3. Backend validates input → Hashes password (bcrypt)
4. Backend generates JWT → Returns token
5. Frontend stores token in localStorage
6. Token added to all subsequent requests

### Task Management Flow
1. User creates task → Opens modal, fills form
2. Frontend validates input → Calls `taskService`
3. Backend verifies JWT → Checks user ownership
4. Backend saves to MongoDB → Returns task
5. Frontend updates context → Updates UI

### State Management Flow
1. AuthContext stores user + token
2. TaskContext stores tasks + filters
3. Components read from context
4. Services fetch from API
5. Context updated with new data

## 🔐 Security Features

1. **Password Hashing**: bcrypt with salt rounds
2. **JWT Auth**: 30-day expiration
3. **CORS**: Limited to frontend URL
4. **Input Validation**: Both client & server
5. **Protected Routes**: React PrivateRoute component
6. **Middleware Auth**: Server-side JWT verification
7. **Error Handling**: No sensitive data leaked

## 📊 Database Schema

### Users Collection
```javascript
{
  name: String (required),
  email: String (required, unique),
  password: String (hashed),
  createdAt: Date
}
```

### Tasks Collection
```javascript
{
  title: String (required),
  description: String,
  priority: String (Low|Medium|High),
  dueDate: Date,
  stage: String (Todo|In Progress|Done),
  userId: ObjectId (reference),
  createdAt: Date,
  updatedAt: Date
}
```

## 🚀 Build & Deployment

### Local Development
- Frontend: `npm run dev` → Vite dev server
- Backend: `npm run dev` → Nodemon auto-reload

### Production Build
- Frontend: `npm run build` → Creates `dist/` folder
- Backend: Ready as-is (no build needed)

### Deployment Targets
- Frontend → Vercel (via Git push)
- Backend → Render (via Git push)
- Database → MongoDB Atlas (cloud hosted)

## 📝 Code Quality

- **ESM Modules**: Modern JavaScript syntax
- **Comments**: Minimal but clear where needed
- **Error Handling**: Try-catch with user-friendly messages
- **Validation**: Server-side input validation
- **Reusable Components**: DRY principles applied
- **Folder Organization**: Logical grouping by function

---

**For detailed setup and deployment, see README.md, QUICKSTART.md, and DEPLOYMENT.md**
