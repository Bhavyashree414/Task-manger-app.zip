# API Reference

Complete API documentation for Task Manager Backend

## Base URL

- **Development**: `http://localhost:5000/api`
- **Production**: `https://your-render-url/api`

## Authentication

All protected endpoints require JWT token in Authorization header:

```
Authorization: Bearer <your_jwt_token>
```

Get token from login or register endpoints.

---

## Authentication Endpoints

### Register User

Create a new user account.

```http
POST /auth/register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123"
}
```

**Response** (201 Created):
```json
{
  "success": true,
  "message": "User registered successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "507f1f77bcf86cd799439011",
    "name": "John Doe",
    "email": "john@example.com"
  }
}
```

**Errors**:
- `400`: Invalid input or user already exists
- `500`: Server error

**Validation**:
- Name: Required, max 50 chars
- Email: Required, valid email format
- Password: Required, min 6 chars

---

### Login User

Authenticate user and get JWT token.

```http
POST /auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "password123"
}
```

**Response** (200 OK):
```json
{
  "success": true,
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "507f1f77bcf86cd799439011",
    "name": "John Doe",
    "email": "john@example.com"
  }
}
```

**Errors**:
- `400`: Missing email or password
- `401`: Invalid credentials
- `500`: Server error

---

### Get Current User

Get authenticated user information.

```http
GET /auth/me
Authorization: Bearer <token>
```

**Response** (200 OK):
```json
{
  "success": true,
  "user": {
    "_id": "507f1f77bcf86cd799439011",
    "name": "John Doe",
    "email": "john@example.com",
    "createdAt": "2024-01-15T10:30:00.000Z"
  }
}
```

**Errors**:
- `401`: Unauthorized (invalid/missing token)
- `404`: User not found
- `500`: Server error

---

## Task Endpoints

All task endpoints require authentication.

### Get All Tasks

Retrieve all tasks for authenticated user with optional filters.

```http
GET /tasks?priority=High&stage=Todo&search=meeting
Authorization: Bearer <token>
```

**Query Parameters** (all optional):
- `priority`: Low | Medium | High
- `stage`: Todo | In Progress | Done
- `search`: Search in title and description

**Response** (200 OK):
```json
{
  "success": true,
  "count": 5,
  "tasks": [
    {
      "_id": "507f1f77bcf86cd799439012",
      "title": "Complete project",
      "description": "Finish the task manager app",
      "priority": "High",
      "dueDate": "2024-12-31",
      "stage": "In Progress",
      "userId": "507f1f77bcf86cd799439011",
      "createdAt": "2024-01-15T10:30:00.000Z",
      "updatedAt": "2024-01-15T10:30:00.000Z"
    }
  ]
}
```

**Errors**:
- `401`: Unauthorized
- `500`: Server error

**Example with cURL**:
```bash
curl -X GET "http://localhost:5000/api/tasks?priority=High" \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

---

### Get Single Task

Retrieve a specific task by ID.

```http
GET /tasks/:id
Authorization: Bearer <token>
```

**Path Parameters**:
- `id`: Task ID (MongoDB ObjectId)

**Response** (200 OK):
```json
{
  "success": true,
  "task": {
    "_id": "507f1f77bcf86cd799439012",
    "title": "Complete project",
    "description": "Finish the task manager app",
    "priority": "High",
    "dueDate": "2024-12-31",
    "stage": "In Progress",
    "userId": "507f1f77bcf86cd799439011",
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:30:00.000Z"
  }
}
```

**Errors**:
- `401`: Unauthorized
- `403`: Not task owner
- `404`: Task not found
- `500`: Server error

---

### Create Task

Create a new task.

```http
POST /tasks
Authorization: Bearer <token>
Content-Type: application/json

{
  "title": "New Task",
  "description": "Task description here",
  "priority": "Medium",
  "dueDate": "2024-12-31",
  "stage": "Todo"
}
```

**Request Body**:
- `title`: String (required, max 100 chars)
- `description`: String (optional, max 500 chars)
- `priority`: String (Low | Medium | High)
- `dueDate`: Date (optional, ISO 8601 format)
- `stage`: String (Todo | In Progress | Done)

**Response** (201 Created):
```json
{
  "success": true,
  "message": "Task created successfully",
  "task": {
    "_id": "507f1f77bcf86cd799439013",
    "title": "New Task",
    "description": "Task description here",
    "priority": "Medium",
    "dueDate": "2024-12-31",
    "stage": "Todo",
    "userId": "507f1f77bcf86cd799439011",
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T10:30:00.000Z"
  }
}
```

**Errors**:
- `400`: Validation failed (missing title, etc.)
- `401`: Unauthorized
- `500`: Server error

**Example with cURL**:
```bash
curl -X POST http://localhost:5000/api/tasks \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Buy groceries",
    "priority": "Low",
    "stage": "Todo"
  }'
```

---

### Update Task

Update an existing task.

```http
PUT /tasks/:id
Authorization: Bearer <token>
Content-Type: application/json

{
  "title": "Updated Title",
  "priority": "High",
  "stage": "In Progress"
}
```

**Path Parameters**:
- `id`: Task ID

**Request Body** (all optional):
- `title`: String
- `description`: String
- `priority`: String
- `dueDate`: Date
- `stage`: String

**Response** (200 OK):
```json
{
  "success": true,
  "message": "Task updated successfully",
  "task": {
    "_id": "507f1f77bcf86cd799439013",
    "title": "Updated Title",
    "description": "Task description here",
    "priority": "High",
    "dueDate": "2024-12-31",
    "stage": "In Progress",
    "userId": "507f1f77bcf86cd799439011",
    "createdAt": "2024-01-15T10:30:00.000Z",
    "updatedAt": "2024-01-15T11:00:00.000Z"
  }
}
```

**Errors**:
- `401`: Unauthorized
- `403`: Not task owner
- `404`: Task not found
- `500`: Server error

**Example with cURL**:
```bash
curl -X PUT http://localhost:5000/api/tasks/507f1f77bcf86cd799439013 \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." \
  -H "Content-Type: application/json" \
  -d '{
    "stage": "Done",
    "priority": "High"
  }'
```

---

### Delete Task

Delete a task permanently.

```http
DELETE /tasks/:id
Authorization: Bearer <token>
```

**Path Parameters**:
- `id`: Task ID

**Response** (200 OK):
```json
{
  "success": true,
  "message": "Task deleted successfully"
}
```

**Errors**:
- `401`: Unauthorized
- `403`: Not task owner
- `404`: Task not found
- `500`: Server error

**Example with cURL**:
```bash
curl -X DELETE http://localhost:5000/api/tasks/507f1f77bcf86cd799439013 \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

---

## Health Check

Check if server is running.

```http
GET /health
```

**Response** (200 OK):
```json
{
  "message": "Server is running"
}
```

---

## Error Responses

All errors follow this format:

```json
{
  "success": false,
  "message": "Error description here"
}
```

**HTTP Status Codes**:
- `200`: OK - Request successful
- `201`: Created - Resource created successfully
- `400`: Bad Request - Invalid input or validation failed
- `401`: Unauthorized - Missing or invalid token
- `403`: Forbidden - Not authorized for this action
- `404`: Not Found - Resource doesn't exist
- `500`: Server Error - Internal server error

---

## Rate Limiting

Currently no rate limiting is implemented. For production, consider adding:
- Rate limiting middleware
- Request throttling
- API key authentication

---

## Response Format

All successful responses include `success: true`:

```json
{
  "success": true,
  "message": "Optional success message",
  "data": "Response data or object"
}
```

All error responses include `success: false`:

```json
{
  "success": false,
  "message": "Error description"
}
```

---

## Pagination

Currently not implemented. For large datasets, consider adding:
- `?page=1&limit=20` parameters
- Cursor-based pagination
- Response metadata (total count, has more)

---

## Request/Response Examples

### Complete Workflow

```bash
# 1. Register
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John",
    "email": "john@example.com",
    "password": "password123"
  }'
# Response includes token

# 2. Create task
TOKEN="your_token_here"
curl -X POST http://localhost:5000/api/tasks \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Buy milk",
    "priority": "High",
    "stage": "Todo"
  }'

# 3. Get all tasks
curl -X GET http://localhost:5000/api/tasks \
  -H "Authorization: Bearer $TOKEN"

# 4. Update task
curl -X PUT http://localhost:5000/api/tasks/TASK_ID \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"stage": "In Progress"}'

# 5. Delete task
curl -X DELETE http://localhost:5000/api/tasks/TASK_ID \
  -H "Authorization: Bearer $TOKEN"
```

---

## Testing with Postman

1. Create Postman collection
2. Set base URL: `http://localhost:5000/api`
3. Add Auth header: `Authorization: Bearer {{token}}`
4. Test all endpoints
5. Export collection for sharing

---

## Troubleshooting

**Q: Getting 401 Unauthorized**
- Check token is included in Authorization header
- Verify token hasn't expired (30 days)
- Get new token by logging in

**Q: Getting 403 Forbidden**
- Verify you own the resource (same userId)
- Check you have required permissions

**Q: Getting 404 Not Found**
- Check resource ID is correct
- Verify resource exists

**Q: Getting 500 Server Error**
- Check backend logs
- Verify database connection
- Check request format is valid

---

**For more information, see README.md and QUICKSTART.md**
