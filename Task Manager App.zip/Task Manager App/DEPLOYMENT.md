# Deployment Guide - Python Stack

## Deploying the Task Manager Application

This guide covers deploying the full-stack Python application to production:
- **Backend**: Render, Heroku, or PythonAnywhere
- **Frontend**: Streamlit Cloud or Vercel
- **Database**: PostgreSQL (recommended for production)

---

## Option 1: Deploy Backend to Render (Recommended)

### Prerequisites
- GitHub repository with code pushed
- Render account at https://render.com

### Step 1: Connect Repository

1. Go to [Render](https://render.com)
2. Sign up or log in with GitHub
3. Click "New +" → "Web Service"
4. Connect your GitHub repository
5. Select the repository containing your Task Manager App

### Step 2: Configure Web Service

1. **Name**: Give your service a name (e.g., `task-manager-api`)
2. **Environment**: Select `Python 3`
3. **Build Command**: `pip install -r backend/requirements.txt`
4. **Start Command**: `cd backend && gunicorn app:app`
5. **Plan**: Choose "Free" tier or paid plan

### Step 3: Add Environment Variables

1. In Render dashboard, go to your service
2. Click "Environment"
3. Add the following variables:
   ```
   FLASK_ENV=production
   DATABASE_URL=postgresql://user:password@localhost/taskmanager
   JWT_SECRET_KEY=your_long_random_secret_key_here
   ```

### Step 4: Deploy

1. Click "Create Web Service"
2. Render will automatically deploy
3. Get your backend URL (e.g., `https://task-manager-api.onrender.com`)

---

## Option 2: Deploy Backend to Heroku

### Prerequisites
- Heroku account at https://www.heroku.com
- Heroku CLI installed

### Step 1: Create Heroku App

```bash
heroku login
heroku create task-manager-api
```

### Step 2: Add PostgreSQL Database

```bash
heroku addons:create heroku-postgresql:hobby-dev
```

### Step 3: Set Environment Variables

```bash
heroku config:set FLASK_ENV=production
heroku config:set JWT_SECRET_KEY=your_long_random_secret_key
```

### Step 4: Deploy

```bash
git push heroku main
```

---

## Option 3: Deploy Frontend to Streamlit Cloud

### Prerequisites
- GitHub repository
- Streamlit Cloud account at https://streamlit.io/cloud

### Step 1: Create `streamlit/config.toml`

Create file: `frontend/.streamlit/config.toml`
```toml
[server]
headless = true
port = 8501

[client]
showErrorDetails = false
```

### Step 2: Create `requirements.txt` in frontend/

Ensure `frontend/requirements.txt` exists with:
```
streamlit==1.28.1
requests==2.31.0
python-dotenv==1.0.0
```

### Step 3: Push to GitHub

```bash
git add .
git commit -m "Add Streamlit deployment config"
git push origin main
```

### Step 4: Deploy to Streamlit Cloud

1. Go to [Streamlit Cloud](https://streamlit.io/cloud)
2. Click "New app"
3. Select your repository
4. Set:
   - **Repository**: your-repo
   - **Branch**: main
   - **Main file path**: `frontend/app.py`
5. Click "Deploy"

### Step 5: Add Secrets

1. In Streamlit Cloud dashboard, click your app
2. Click "Settings" → "Secrets"
3. Add environment variables:
   ```
   API_URL=https://your-backend-url.onrender.com
   ```

---

## Option 4: PostgreSQL Setup (Production Database)

### Using Render PostgreSQL

1. In Render dashboard, click "New +" → "PostgreSQL"
2. Give it a name (e.g., `task-manager-db`)
3. Choose plan (Free tier available)
4. Copy the external database URL
5. Set as `DATABASE_URL` in backend environment

### Using Railway PostgreSQL

1. Go to https://railway.app
2. Create new PostgreSQL database
3. Copy connection string
4. Use as `DATABASE_URL`

---

## Environment Variables Checklist

### Backend
```
FLASK_ENV=production
DATABASE_URL=postgresql://user:pass@host/dbname
JWT_SECRET_KEY=your_secret_key_32_chars_minimum
```

### Frontend
```
API_URL=https://your-backend-url.com
```

---

## Post-Deployment Testing

1. **Test Backend Health**
   ```bash
   curl https://your-backend-url/api/health
   ```

2. **Test Frontend Access**
   - Visit Streamlit Cloud URL
   - Try registering a new account
   - Create and manage tasks

3. **Check Logs**
   - Backend logs: Check Render/Heroku dashboard
   - Frontend logs: Check Streamlit Cloud logs

---

## Database Migration to PostgreSQL

If switching from SQLite to PostgreSQL:

1. Update `backend/config.py`:
   ```python
   DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql://localhost/taskmanager')
   ```

2. Install PostgreSQL driver:
   ```bash
   pip install psycopg2-binary
   ```

3. Run migrations (if using Alembic):
   ```bash
   alembic upgrade head
   ```

---

## Troubleshooting Deployment

### Backend won't start
- Check logs in deployment platform
- Verify DATABASE_URL is set correctly
- Ensure all dependencies in requirements.txt

### Frontend can't connect to backend
- Verify API_URL in frontend secrets
- Check CORS is enabled in Flask backend
- Verify JWT_SECRET_KEY matches between environments

### Database connection errors
- Test connection string locally first
- Verify IP whitelist if using managed database
- Check credentials are URL-encoded

### Cold start delays
- Normal for free tier services
- Consider upgrading to paid plans for better performance
```
mongodb+srv://taskmanager:password123@cluster0.abcde.mongodb.net/task-manager?retryWrites=true&w=majority
```

---

## Step 2: Backend Deployment (Render)

### Prepare Backend

1. Push your code to GitHub repository
2. Ensure all code is committed (no uncommitted changes)

### Create Render Account

1. Go to [Render.com](https://render.com)
2. Sign up with GitHub account
3. Authorize Render to access your repositories

### Create Web Service

1. Click "New" → "Web Service"
2. Connect your GitHub repository
3. Select the repository containing your code

### Configure Web Service

1. **Name**: `task-manager-backend`
2. **Root Directory**: `server` (leave empty if at root)
3. **Environment**: `Node`
4. **Build Command**: `npm install`
5. **Start Command**: `npm start`
6. **Plan**: Free tier (sufficient for demo)

### Add Environment Variables

Click "Add Environment Variable" for each:

| Key | Value |
|-----|-------|
| `MONGODB_URI` | Your MongoDB connection string |
| `JWT_SECRET` | Generate strong random string (example: `your-super-secret-jwt-key-min-32-chars-long!`) |
| `NODE_ENV` | `production` |
| `FRONTEND_URL` | Your Vercel frontend URL (add later) |
| `PORT` | `5000` (optional, Render assigns port automatically) |

Generate strong JWT secret:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### Deploy

1. Click "Create Web Service"
2. Render will automatically deploy
3. Once deployed, you'll get a URL like: `https://task-manager-backend.onrender.com`
4. **Important**: First request after inactivity may be slow (free tier limitation)

### Update Frontend URL

After getting your Render URL:
1. Go back to Render environment variables
2. Update `FRONTEND_URL` with your Vercel deployment URL
3. Save

---

## Step 3: Frontend Deployment (Vercel)

### Prepare Frontend

1. Ensure `client/.env` has production API URL
2. Push code to GitHub

### Create Vercel Account

1. Go to [Vercel.com](https://vercel.com)
2. Sign up with GitHub account
3. Authorize Vercel to access repositories

### Import Project

1. Click "Add New..." → "Project"
2. Select your repository
3. Vercel auto-detects it's a Monorepo

### Configure Project

1. **Project Name**: `task-manager`
2. **Framework Preset**: Vite
3. **Root Directory**: Set to `client`
4. **Build Command**: `npm run build`
5. **Output Directory**: `dist`
6. **Install Command**: `npm install`

### Add Environment Variables

1. Click "Environment Variables"
2. Add variable:
   - **Name**: `VITE_API_URL`
   - **Value**: Your Render backend URL (e.g., `https://task-manager-backend.onrender.com`)
3. Click "Add"

### Deploy

1. Click "Deploy"
2. Vercel will build and deploy
3. You'll get a URL like: `https://task-manager.vercel.app`

---

## Step 4: Update Render with Vercel URL

1. Go back to Render dashboard
2. Select your web service
3. Go to "Environment"
4. Update `FRONTEND_URL` to your Vercel URL
5. Click "Save Changes"
6. Service will auto-redeploy

---

## Step 5: Test Production Deployment

### Test Backend

1. Open: `https://your-render-url/api/health`
2. Should return: `{"message":"Server is running"}`

### Test Frontend

1. Open your Vercel URL
2. Register a new account
3. Create, edit, and delete tasks
4. Verify filters and search work

---

## Environment Variables Checklist

### MongoDB Atlas
- [ ] Cluster created (M0 free tier)
- [ ] Database user created
- [ ] Connection string obtained
- [ ] Whitelist all IPs (recommended for testing: 0.0.0.0/0)

### Backend (Render)
- [ ] GitHub repository pushed
- [ ] Render account created
- [ ] Web service created
- [ ] All environment variables set:
  - [ ] `MONGODB_URI`
  - [ ] `JWT_SECRET`
  - [ ] `NODE_ENV=production`
  - [ ] `FRONTEND_URL`

### Frontend (Vercel)
- [ ] Vercel account created
- [ ] Project imported
- [ ] Environment variables set:
  - [ ] `VITE_API_URL` (Render backend URL)
- [ ] Successfully deployed

---

## Troubleshooting

### Backend not connecting to MongoDB

**Error**: `MongoNetworkError` or `connection refused`

**Solution**:
1. Verify connection string in `.env`
2. Check MongoDB Atlas IP whitelist includes Render IPs
3. In MongoDB Atlas: Network Access → Edit → Allow access from anywhere (0.0.0.0/0)

### CORS Error in Frontend

**Error**: `Access to XMLHttpRequest blocked by CORS policy`

**Solution**:
1. Check `FRONTEND_URL` is set correctly in backend `.env`
2. Verify CORS is enabled in `server.js`:
   ```javascript
   app.use(cors({
     origin: process.env.FRONTEND_URL || 'http://localhost:5173',
     credentials: true,
   }));
   ```

### API URL Not Found

**Error**: Cannot find `/api/tasks` or similar

**Solution**:
1. Verify `VITE_API_URL` in frontend `.env` is correct
2. Check it matches your Render backend URL
3. Redeploy frontend after updating URL

### JWT Token Issues

**Error**: `Not authorized to access this route`

**Solution**:
1. Generate new JWT secret if needed:
   ```bash
   node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
   ```
2. Update in Render environment variables
3. Restart web service

### Render Service Keeps Timing Out

**Solution** (Free tier limitation):
1. Consider upgrading to paid plan
2. Or set up monitoring to keep service warm
3. First request after inactivity may take 30+ seconds

---

## Performance Tips

### Optimize MongoDB

1. Add indexes on frequently queried fields
2. Limit results in API responses
3. Use pagination for large datasets

### Optimize Frontend

1. Enable Gzip compression in Vercel
2. Optimize images
3. Split code for lazy loading
4. Use React.memo for expensive components

### Monitor Deployments

1. **Render**: Check "Logs" tab for errors
2. **Vercel**: Check deployment logs and analytics
3. **MongoDB**: Check "Monitoring" for query performance

---

## Security Checklist

- [ ] JWT_SECRET is long (32+ chars) and random
- [ ] MONGODB_URI with strong password
- [ ] CORS whitelist only includes your domain
- [ ] Sensitive data not in client-side code
- [ ] HTTPS enforced (automatic on Vercel/Render)
- [ ] Database backups enabled (MongoDB Atlas settings)
- [ ] Regular security updates applied

---

## Scaling for Production

When you need to scale:

### Database
1. Upgrade MongoDB cluster tier
2. Enable auto-scaling storage
3. Set up sharding for large datasets

### Backend
1. Upgrade Render plan for better resources
2. Add caching layer (Redis)
3. Implement rate limiting

### Frontend
1. Enable CDN caching
2. Implement service workers
3. Add analytics for monitoring

---

## Rollback Procedure

### If Deployment Fails

**Render**:
1. Go to "Deploys" tab
2. Click previous successful deployment
3. Click "Redeploy"

**Vercel**:
1. Go to "Deployments"
2. Click previous successful deployment
3. Click "Promote to Production"

---

## Maintenance

### Regular Tasks

- [ ] Monitor logs for errors
- [ ] Check API response times
- [ ] Verify backups are working
- [ ] Update dependencies monthly
- [ ] Review MongoDB Atlas status

### Updating Code

1. Make changes locally
2. Test thoroughly
3. Push to GitHub
4. Automatic deployment triggered
5. Verify in production

---

## Support & Resources

- [Render Documentation](https://render.com/docs)
- [Vercel Documentation](https://vercel.com/docs)
- [MongoDB Atlas Documentation](https://docs.atlas.mongodb.com/)
- [Express.js Documentation](https://expressjs.com/)
- [React Documentation](https://react.dev/)

---

**Deployment is now complete! Your application is live and accessible worldwide.** 🚀
