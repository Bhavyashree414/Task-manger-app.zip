# Quick Start Guide

Get the Task Manager application running locally in 5 minutes!

## Prerequisites

- Node.js v14+ installed
- npm or yarn package manager
- MongoDB connection string (MongoDB Atlas or local MongoDB)
- Git

## 1️⃣ Clone and Setup

### Backend Setup

```bash
cd server
npm install
```

Create `.env` file:
```bash
cp .env.example .env
```

Edit `.env` and add your MongoDB URI:
```
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/task-manager
JWT_SECRET=your_super_secret_jwt_key_here_make_it_long
```

Start backend:
```bash
npm run dev
```

Server runs on `http://localhost:5000`

### Frontend Setup (New Terminal)

```bash
cd client
npm install
```

Create `.env` file:
```bash
cp .env.example .env
```

The `.env` should already have:
```
VITE_API_URL=http://localhost:5000
```

Start frontend:
```bash
npm run dev
```

Open browser to `http://localhost:5173`

## 2️⃣ Test the Application

### Register & Login

1. Click "Register"
2. Fill in:
   - Name: Your name
   - Email: your@email.com
   - Password: password123
3. Click "Register" → Auto login and redirects to dashboard

### Create Tasks

1. Click "Add New Task"
2. Fill in:
   - Title: "My first task"
   - Description: Optional
   - Priority: Medium
   - Due Date: Pick a date
   - Stage: Todo
3. Click "Create Task"

### Manage Tasks

- **Edit**: Click edit icon on task card
- **Delete**: Click delete icon on task card
- **Filter**: Use search, priority, and stage filters
- **View Stats**: See task counts in statistics boxes

## 3️⃣ File Structure

```
Task Manager App/
├── README.md           # Full documentation
├── DEPLOYMENT.md       # Deployment guide
├── QUICKSTART.md       # This file
│
├── client/             # React frontend
│   ├── src/
│   │   ├── components/ # UI components
│   │   ├── pages/      # Page components
│   │   ├── services/   # API services
│   │   ├── context/    # State management
│   │   └── App.jsx     # Main app
│   └── package.json
│
└── server/             # Express backend
    ├── models/         # MongoDB schemas
    ├── controllers/    # Business logic
    ├── routes/         # API routes
    ├── middleware/     # Custom middleware
    └── server.js       # Entry point
```

## 4️⃣ API Examples

### Register
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"John","email":"john@example.com","password":"pass123"}'
```

### Login
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"john@example.com","password":"pass123"}'
```

### Create Task
```bash
curl -X POST http://localhost:5000/api/tasks \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "title":"My task",
    "description":"Do something",
    "priority":"High",
    "stage":"Todo"
  }'
```

### Get Tasks
```bash
curl -X GET "http://localhost:5000/api/tasks?priority=High&stage=Todo" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## 5️⃣ Troubleshooting

### Port Already in Use

**Problem**: `EADDRINUSE: address already in use :::5000`

**Solution**:
```bash
# Find process using port 5000
netstat -ano | findstr :5000
# Kill it
taskkill /PID <PID> /F
```

### MongoDB Connection Error

**Problem**: `MongoNetworkError: connect ECONNREFUSED`

**Solution**:
1. Verify MongoDB URI in `.env`
2. Check MongoDB is running (if local)
3. Add your IP to MongoDB Atlas whitelist

### CORS Error

**Problem**: `Access to XMLHttpRequest has been blocked by CORS policy`

**Solution**:
1. Verify backend is running
2. Check `VITE_API_URL` in client `.env`
3. Verify server.js has CORS enabled

### Port 5173 Not Available

**Problem**: Frontend won't start on port 5173

**Solution**:
```bash
# Use different port
npm run dev -- --port 5174
```

## 6️⃣ Common Commands

### Backend
```bash
npm install          # Install dependencies
npm run dev         # Start dev server with hot reload
npm start           # Start production server
```

### Frontend
```bash
npm install         # Install dependencies
npm run dev        # Start dev server
npm run build      # Build for production
npm run preview    # Preview production build
```

## 7️⃣ Features Overview

✅ **Authentication**
- Register with name, email, password
- Login with email, password
- JWT token stored in localStorage
- Logout and clear token

✅ **Task Management**
- Create tasks with title, description, priority, due date, stage
- Edit existing tasks
- Delete tasks
- Move tasks between Todo, In Progress, Done

✅ **Filtering & Search**
- Search by task title
- Filter by priority (Low, Medium, High)
- Filter by stage (Todo, In Progress, Done)
- Clear all filters

✅ **Dashboard**
- View task statistics
- Task count for each stage
- Quick add task button
- Responsive design

✅ **Error Handling**
- Form validation
- Toast notifications
- Error messages
- Automatic logout on 401

## 8️⃣ Next Steps

1. **Customize**: Modify colors in `tailwind.config.js`
2. **Add Features**: 
   - Dark mode toggle
   - Task categories
   - Drag & drop between columns
3. **Deploy**: Follow `DEPLOYMENT.md` for production
4. **Monitor**: Set up error tracking (Sentry)
5. **Optimize**: Add caching, pagination

## 9️⃣ Learning Resources

- **React**: https://react.dev/
- **Express**: https://expressjs.com/
- **MongoDB**: https://docs.mongodb.com/
- **Tailwind CSS**: https://tailwindcss.com/
- **JWT**: https://jwt.io/

## 🔟 Support

**Still stuck?**
1. Check browser console (F12) for frontend errors
2. Check terminal for backend errors
3. Review `README.md` for detailed documentation
4. Check `DEPLOYMENT.md` for production issues

---

**Happy coding! 🚀**

Need help? Create an issue on GitHub or check the documentation files.
