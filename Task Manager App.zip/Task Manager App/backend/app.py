import os
from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from models import db
from auth import auth_bp
from tasks import tasks_bp
from dotenv import load_dotenv
from config import config

load_dotenv()

def create_app(config_name='development'):
    app = Flask(__name__)
    app.config.from_object(config.get(config_name, config['development']))
    
    db.init_app(app)
    jwt = JWTManager(app)
    CORS(app)
    
    with app.app_context():
        db.create_all()
    
    app.register_blueprint(auth_bp)
    app.register_blueprint(tasks_bp)
    
    @app.route('/api/health', methods=['GET'])
    def health_check():
        return {'status': 'ok'}, 200
    
    return app

if __name__ == '__main__':
    app = create_app(os.getenv('FLASK_ENV', 'development'))
    app.run(debug=True, host='0.0.0.0', port=5000)
