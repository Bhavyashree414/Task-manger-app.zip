import os
from datetime import datetime
import requests
from dotenv import load_dotenv

load_dotenv()

API_URL = os.getenv('API_URL', 'http://localhost:5000')

class APIClient:
    def __init__(self):
        self.api_url = API_URL
        self.token = None
    
    def set_token(self, token):
        self.token = token
    
    def _get_headers(self):
        headers = {'Content-Type': 'application/json'}
        if self.token:
            headers['Authorization'] = f'Bearer {self.token}'
        return headers
    
    def register(self, username, email, password):
        response = requests.post(
            f'{self.api_url}/api/auth/register',
            json={'username': username, 'email': email, 'password': password},
            headers=self._get_headers()
        )
        return response
    
    def login(self, email, password):
        response = requests.post(
            f'{self.api_url}/api/auth/login',
            json={'email': email, 'password': password},
            headers=self._get_headers()
        )
        return response
    
    def get_current_user(self):
        response = requests.get(
            f'{self.api_url}/api/auth/me',
            headers=self._get_headers()
        )
        return response
    
    def get_tasks(self, status=None):
        params = {'status': status} if status else {}
        response = requests.get(
            f'{self.api_url}/api/tasks',
            headers=self._get_headers(),
            params=params
        )
        return response
    
    def create_task(self, title, description, status, priority, due_date):
        response = requests.post(
            f'{self.api_url}/api/tasks',
            json={
                'title': title,
                'description': description,
                'status': status,
                'priority': priority,
                'due_date': due_date
            },
            headers=self._get_headers()
        )
        return response
    
    def update_task(self, task_id, title, description, status, priority, due_date):
        response = requests.put(
            f'{self.api_url}/api/tasks/{task_id}',
            json={
                'title': title,
                'description': description,
                'status': status,
                'priority': priority,
                'due_date': due_date
            },
            headers=self._get_headers()
        )
        return response
    
    def delete_task(self, task_id):
        response = requests.delete(
            f'{self.api_url}/api/tasks/{task_id}',
            headers=self._get_headers()
        )
        return response
