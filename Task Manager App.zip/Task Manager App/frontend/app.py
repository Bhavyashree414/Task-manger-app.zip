import streamlit as st
from api_client import APIClient
from datetime import datetime

st.set_page_config(page_title="Task Manager", layout="wide")

client = APIClient()

if 'token' not in st.session_state:
    st.session_state.token = None
if 'user' not in st.session_state:
    st.session_state.user = None

def login_page():
    st.title("Task Manager - Login")
    
    tab1, tab2 = st.tabs(["Login", "Register"])
    
    with tab1:
        email = st.text_input("Email", key="login_email")
        password = st.text_input("Password", type="password", key="login_password")
        
        if st.button("Login"):
            response = client.login(email, password)
            if response.status_code == 200:
                data = response.json()
                st.session_state.token = data['token']
                st.session_state.user = data['user']
                client.set_token(st.session_state.token)
                st.success("Logged in successfully!")
                st.rerun()
            else:
                st.error(response.json().get('error', 'Login failed'))
    
    with tab2:
        username = st.text_input("Username", key="register_username")
        email = st.text_input("Email", key="register_email")
        password = st.text_input("Password", type="password", key="register_password")
        
        if st.button("Register"):
            response = client.register(username, email, password)
            if response.status_code == 201:
                st.success("Registered successfully! Please login.")
            else:
                st.error(response.json().get('error', 'Registration failed'))

def task_page():
    st.title(f"Task Manager - Welcome {st.session_state.user['username']}")
    
    col1, col2 = st.columns([4, 1])
    with col2:
        if st.button("Logout"):
            st.session_state.token = None
            st.session_state.user = None
            st.rerun()
    
    tab1, tab2 = st.tabs(["All Tasks", "Create Task"])
    
    with tab1:
        status_filter = st.selectbox("Filter by status", ["All", "todo", "in_progress", "done"])
        
        response = client.get_tasks(status=None if status_filter == "All" else status_filter)
        
        if response.status_code == 200:
            tasks = response.json()
            
            if not tasks:
                st.info("No tasks found")
            else:
                for task in tasks:
                    with st.expander(f"📌 {task['title']} - {task['status'].upper()}"):
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            st.write(f"**Priority:** {task['priority']}")
                            st.write(f"**Status:** {task['status']}")
                        
                        with col2:
                            st.write(f"**Description:** {task['description'] or 'N/A'}")
                            st.write(f"**Due Date:** {task['due_date'] or 'No due date'}")
                        
                        with col3:
                            if st.button("Edit", key=f"edit_{task['id']}"):
                                st.session_state.edit_task_id = task['id']
                            if st.button("Delete", key=f"delete_{task['id']}"):
                                del_response = client.delete_task(task['id'])
                                if del_response.status_code == 200:
                                    st.success("Task deleted!")
                                    st.rerun()
                                else:
                                    st.error("Failed to delete task")
        else:
            st.error("Failed to fetch tasks")
    
    with tab2:
        with st.form("create_task_form"):
            title = st.text_input("Task Title")
            description = st.text_area("Description")
            status = st.selectbox("Status", ["todo", "in_progress", "done"])
            priority = st.selectbox("Priority", ["low", "medium", "high"])
            due_date = st.date_input("Due Date")
            
            if st.form_submit_button("Create Task"):
                response = client.create_task(
                    title, description, status, priority, due_date.isoformat() if due_date else None
                )
                if response.status_code == 201:
                    st.success("Task created!")
                    st.rerun()
                else:
                    st.error(response.json().get('error', 'Failed to create task'))

if st.session_state.token:
    client.set_token(st.session_state.token)
    task_page()
else:
    login_page()
